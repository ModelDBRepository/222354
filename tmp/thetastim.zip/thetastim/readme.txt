These NEURON files demonstrate a Theta Stimulation mechanism
created by Tom Morse by modifiying NetStim.mod

Download and compile the mod files with nrnivmodl (linux/unix) or 
mknrndll (mac and pc).

Start with "nrngui init.hoc" (linux/unix) or by double clicking init.hoc
(mswin) or by dragging and dropping the init.hoc file on the nrngui icon (mac).

A Theta Stimulation protocol is one where a smaller group of spikes
say 4 at 50 Hz is repeated at a longer interval, for example every 100 ms.
Run the demo to experiment with different settings.
